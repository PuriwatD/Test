# Flutter Facebook Responsive UI Tutorial

[YouTube Tutorial](https://youtu.be/HvLb5gdUfDE)

[Widget & File Structure Diagram](https://drive.google.com/file/d/183A5x2v5yyEFubuN2p12_dPx3yt6SJu-/view)

![Mobile Screenshot](screenshots/facebook-mobile.png)

![Web Screenshot](screenshots/facebook-web.png)

![Widget & File Structure Diagram](screenshots/widget_file_structure_diagram.png)